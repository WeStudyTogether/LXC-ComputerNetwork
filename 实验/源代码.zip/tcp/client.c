#include <stdio.h>
#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#define MAX 80 
#define PORT 8080 
#define SA struct sockaddr 

void chat(int sockfd) 
{ 
	char buff[MAX]; 
	int n; 
	printf("Please enter string, enter exit means close the process\n");
	while(1) { 
		bzero(buff, sizeof(buff)); 
		printf("Enter the string : "); 
		n = 0; 
		while ((buff[n++] = getchar()) != '\n') 
			;
		buff[n] = '\0'; 

		//send message
        write(sockfd, buff, strlen(buff));                        //todo

		if ((strncmp(buff, "exit", 4)) == 0) { 
			printf("Client Exit...\n"); 
			break; 
		}
		bzero(buff, sizeof(buff)); 

		//read message
        read(sockfd, buff, sizeof(buff));                        //todo

		printf("Received from Server : %s\n", buff);  
	} 
} 

int main() 
{ 
	int sockfd, connfd; 
	struct sockaddr_in servaddr, cli; 

	// socket create and varification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0);            //todo
    if (sockfd == -1) {
    	printf("socket failed");
    	exit(-1);
    }

	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	servaddr.sin_port = htons(PORT); 

	// connect the client socket to server socket
    connfd = connect(sockfd, (struct socketaddr *)&servaddr, sizeof(servaddr));            //todo
    if (connfd == -1) {
    	printf("connect failed");
    	exit(-1);
    }

    printf("connect success");
	// function for chat 
	chat(sockfd); 

	// close the socket 
	close(sockfd); 
} 
