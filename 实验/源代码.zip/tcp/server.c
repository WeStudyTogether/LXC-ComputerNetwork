#include <stdio.h>
#include <ctype.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#define MAX 80 
#define PORT 8080 
#define SA struct sockaddr 

//Function convert string to uppercase
void convert(char *src, char *dest, int len) {
	//todo
	for (int i  = 0; i < len - 1; i++) {
		if (src[i] >= 97 && src[i] <= 122) {
			dest[i] = src[i] - 32;
		}
		else {
			dest[i] = src[i];
		}
	}
}

// Function designed for chat between client and server. 
void chat(int sockfd) 
{ 
	char buff[MAX]; 
                char result[MAX];
	int n; 
	// infinite loop for chat 
	while(1) { 
		bzero(buff, MAX); 

		// read the message from client and copy it in buffer 
		recv(sockfd, buff, sizeof(buff), 0);//todo

		// print buffer which contains the client contents 
		printf("Received from client: %s", buff); 

		//convert to uppercase
		bzero(result, MAX);
		convert(buff, result, strlen(buff));

		// and send that result to client 
		send(sockfd, result, sizeof(result), 0);//todo

	} 
}

// Driver function 
int main() 
{ 
	int sockfd, connfd;
	struct sockaddr_in servaddr, cli; 

	// socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);            //todo

	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

	// Binding newly created socket to given IP and verification 
    connfd = bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));            //todo
    if (connfd == -1) {
    	printf("bind failed");
    	exit(-1);
    }
	// Now server is ready to listen and verification 
    connfd = listen(sockfd, PORT);            //todo
    if (connfd == -1) {
    	printf("listen failed");
    	exit(-1);
    }

	// Accept the data packet from client and verification
    socklen_t len = sizeof(cli);
    connfd = accept(sockfd, (struct sockaddr *)&cli, &len);            //todo
    if (connfd == -1) {
    	printf("accept failed");
    	exit(-1);
    }
	// Function for chatting between client and server 
	chat(connfd); 

	// After chatting close the socket 
	close(sockfd);
} 
