// Client side implementation of UDP client-server model 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT	 8080 
#define MAXLINE 1024 

// Driver code 
int main() { 
	int sockfd; 
	char *buffer = malloc(sizeof(char)*MAXLINE); 
	struct sockaddr_in	 servaddr; 

	// Creating socket file descriptor 
	sockfd = socket(PF_INET, SOCK_DGRAM, 0);            //todo
	if (sockfd == -1) {
		printf("socket failed");
		exit(-1);
	}
	memset(&servaddr, 0, sizeof(servaddr)); 
	
	// Filling server information 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	
	int n, len; 
	printf("Please enter string, enter exit means close the process\n");
	while(1) {
		printf("Enter message:");

		//get user input
		n = 0;
		bzero(buffer, sizeof(buffer));
		while ((buffer[n++] = getchar()) != '\n');//todo
		buffer[n] = '\0';

		//send message
		sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&servaddr, sizeof(servaddr));//todo

		if ((strncmp(buffer, "exit", 4)) == 0) { 
			printf("Client Exit...\n"); 
			break; 
		}

		//receive message
		len = sizeof(servaddr);//todo
		bzero(buffer, sizeof(buffer));
		recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&servaddr, &len);

		printf("Received server : %s\n", buffer); 
	}

	close(sockfd); 
	return 0; 
} 
