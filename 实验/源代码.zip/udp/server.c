// Server side implementation of UDP client-server model 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>
#include <ctype.h>
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT	 8080 
#define MAXLINE 1024 

// Driver code 
int main() { 
	int sockfd; 
	char buffer[MAXLINE]; 
	struct sockaddr_in servaddr, cliaddr; 
	
	// Creating socket file descriptor 
    sockfd = socket(PF_INET, SOCK_DGRAM, 0);            //todo
	if (sockfd == -1) {
		printf("socket failed");
		exit(-1);
	}

	memset(&servaddr, 0, sizeof(servaddr)); 
	memset(&cliaddr, 0, sizeof(cliaddr)); 
	
	// Filling server information 
	servaddr.sin_family = AF_INET; // IPv4 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT); 
	
	// Bind the socket with the server address 
    int res = bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));            //todo
	if (res == -1) {
		printf("bind failed");
		exit(-1);
	}
	int len, n; 
	while(1) {
	bzero(buffer, sizeof(buffer));
	len = sizeof(cliaddr);
	//receive message
	recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&cliaddr, &len);//todo

	printf("Received client : %s\n", buffer);
	n = 0;

	if ((strncmp(buffer, "exit", 4)) == 0) {
		printf("sever Exit...\n");
		break;
	}
	//convert to uppercase
	//todo
	for (int i = 0; i < strlen(buffer) - 1; i++) {
		if (buffer[i] >= 97 && buffer[i] <= 122) {
			buffer[i] = buffer[i] - 32;
		}
	}
	//send messgae
	sendto(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&cliaddr, sizeof(cliaddr));//todo

	}
	 
	return 0; 
} 
